#!/usr/bin/env python

import rospy
import sys
import math
import tf
from std_msgs.msg import String
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
things_around = None
# if there is anything within .2m, there are things around
def scan_cb(msg):
   global things_around
   things_around = False
   for value in msg.ranges:
      if value != 'inf':
         if value < .2:
            things_around = True
            #print value


# it is not necessary to add more code here but it could be useful
def key_cb(msg):
   global state; global last_key_press_time
   state = msg.data
   last_key_press_time = rospy.Time.now()


odom_cb_msg = None
# odom is also not necessary but very useful
def odom_cb(msg):
   global odom_cb_msg
   odom_cb_msg = msg.pose.pose

def close_to(x, y):
   return x > y-.1 and x < y + .1


# print the state of the robot
def print_state():
   print("---")
   print("STATE: " + state)

   # calculate time since last key stroke
   time_since = rospy.Time.now() - last_key_press_time
   print("SECS SINCE LAST KEY PRESS: " + str(time_since.secs))

# init node
rospy.init_node('dancer')

# subscribers/publishers
scan_sub = rospy.Subscriber('scan', LaserScan, scan_cb)

# RUN rosrun prrexamples key_publisher.py to get /keys
key_sub = rospy.Subscriber('keys', String, key_cb)
odom_sub = rospy.Subscriber('odom', Odometry, odom_cb)
cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)

# start in state halted and grab the current time
state = "H"
last_key_press_time = rospy.Time.now()

# set rate
rate = rospy.Rate(10)

#current move is an array of the linear and angular movement
global current_move 
current_move = [0,0]
counter1 = 0
counter2 = 0
counter3 = 0
# Wait for published topics, exit on ^c
while not rospy.is_shutdown():

   # print out the current state and time since last key press
   print_state()
   
   # publish cmd_vel from here 
   t = Twist()
   #basic commands (forward, back, left, right, halt or things in front)
   if state == 'H' or things_around:
      current_move = [0, 0]
   elif state == 'F':
      current_move = [.1, 0]
   elif state == 'B':
      current_move = [-.1, 0]
   elif state == 'L':
      current_move = [0, .1] #make sure its rotating correctly
   elif state == 'R':
      current_move = [0, -.1] #again, make sure
   elif state == 'S':
       #spiral: if the command is just coming in, set it equal to the turning velocities
       #else, every 5 seconds divide it by 1.1 until it equals a small enough value
       #that it just becomes 0 and sits there until new commands come in
      turning_velocity = .3
      movement_velocity = .5
      if current_move[0] == .1 or current_move[0] == 0:
         current_move[0] = movement_velocity
         current_move[1] = turning_velocity
      if counter1 == 5:
         current_move[0] = current_move[0]/ 1.1
         counter1 = 0
      else:
         counter1 = counter1 + 1
      if current_move[0] < .001:
         current_move[0] = 0
         current_move[1] = 0
         state = 'H'
      t.linear.x = current_move[0]
      t.angular.z = current_move[1]
      cmd_vel_pub.publish(t)
   elif state == 'Z':
      #zig zag: 1-10 = turn, 10-20 = move, 20-30 = turn back 30-40 = move
      if counter2 < 10:
         current_move[0] = 0
         current_move[1] = .5
         t.linear.x = 0
         t.angular.z = .5
         cmd_vel_pub.publish(t)
         counter2 = counter2 + 1
      elif counter2 >= 10 and counter2 < 20:
         current_move[0] = .1
         current_move[1] = 0
         t.linear.x = .1
         t.angular.z = 0
         cmd_vel_pub.publish(t)
         counter2 = counter2 + 1
      elif counter2 >=20 and counter2 < 30:
         current_move[0] = 0
         current_move[1] = -.5
         t.linear.x = 0
         t.angular.z = -.5
         cmd_vel_pub.publish(t)
         counter2 = counter2 + 1
      elif counter2 >= 30 and counter2 < 40: 
         current_move[0] = .1
         current_move[1] = 0
         t.linear.x = .1
         t.angular.z = 0
         cmd_vel_pub.publish(t)
         counter2 = counter2 + 1
      else:
         counter2 = 0
   elif state == 'P':
       #attempt at making a pentagon (failed, but left the code in)
      quaternion_list = odom_cb_msg.orientation 
      quaternion_tuple = (quaternion_list.x, quaternion_list.y, quaternion_list.z, quaternion_list.w)
      euler = tf.transformations.euler_from_quaternion(quaternion_tuple)
      if counter3 == 0 and not close_to(euler[2], 0):
         current_move[0] = 0
         current_move[1] = .1
      elif counter3 < 10 and close_to(euler[2], 0):
         current_move[0] = .5
         current_move[1] = 0
         counter3 = counter3 + 1
      elif counter3 == 10 and not close_to(euler[2], 1.074):
         current_move[0] = 0
         current_move[1] = .1
      elif counter3 < 20 and close_to(euler[2], 1.074):
         current_move[0] = .5
         current_move[1] = 0
         counter3 = counter3 + 1
      elif counter3 == 20 and not close_to(euler[2], 2.148):
         current_move[0] = 0
         current_move[1] = .1
      elif counter3 < 30 and close_to(euler[2], 2.148):
         current_move[0] = .5
         current_move[1] = 0
         counter3 = counter3 + 1
      elif counter3 == 30 and not close_to(euler[2], 3.14):
         current_move[0] = 0
         current_move[1] = .1
      elif counter3 < 40 and close_to(euler[2], 3.14):
         current_move[0] = .5
         current_move[1] = 0
         counter3 = counter3 + 1
      elif counter3 == 40 and not close_to(euler[2], -2.148):
         current_move[0] = 0
         current_move[1] = .1
      elif counter3 < 50 and close_to(euler[2], -2.148):
         current_move[0] = .5
         current_move[1] = 0
         counter3 = counter3 + 1
      elif counter3 == 50 and not close_to(euler[2], -1.074):
         current_move[0] = 0
         current_move[1] = .1
      elif counter3 < 60 and close_to(euler[2], -1.074):
         current_move[0] = .5
         current_move[1] = 0
         counter3 = counter3 + 1
         
      else:
         counter3 = 0
         print 'hexagon is finished!'
   else:     
      print('not a valid key! Try again!')
   t.linear.x = current_move[0] 
   t.angular.z = current_move[1] 
   
   if odom_cb_msg != None:
      print 'SPEED OF ROBOT:' + str(t.linear.x)
      print 'LOCATION OF ROBOT: X: ' + str(odom_cb_msg.position.x) + ' Y: ' + str(odom_cb_msg.position.y) + ' Z: ' + str(odom_cb_msg.position.z)
   cmd_vel_pub.publish(t)

   # run at 10hz
   rate.sleep()

   # one idea: use vector-2 to represent linear and angular velocity
   # velocity_vector = [linear_component, angular_component]
   # then represent:
   # twist.linear.x = LINEAR_SPEED * linear_component
   # twist.angular.z = ANGULAR_SPEED * angular_component 
   # where for example:
   # LINEAR_SPEED = 0.2, ANGULAR_SPEED = pi/4
   # velocity_vector = [1, 0] for positive linear and no angular movement
   # velocity_vector = [-1, 1] for negative linear and positive angular movement
   # we can then create a dictionary state: movement_vector to hash the current position to get the movement_vector
   # in order to get the zig zag and spiral motion you could you something like this:
   # twist.linear.x = LINEAR_SPEED * linear_component * linear_transform
   # twist.angular.z = ANGULAR_SPEED * angular_component * angular_transform
   # where the [linear_transform, angular_transform] is derived from another source that is based on the clock
   # now you can change the velocity of the robot at every step of the program based on the state and the time

